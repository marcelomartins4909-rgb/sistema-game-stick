const{contextBridge,ipcRenderer}=require('electron');
const b64=s=>btoa(unescape(encodeURIComponent(s))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
contextBridge.exposeInMainWorld('glElectron',{
 pickDir:()=>ipcRenderer.invoke('pickDir'),openRoms:()=>ipcRenderer.invoke('openRoms'),openBase:()=>ipcRenderer.invoke('openBase'),openDownloads:()=>ipcRenderer.invoke('openDownloads'),
 romsDefault:()=>ipcRenderer.invoke('romsDefault'),allow:d=>ipcRenderer.invoke('allow',d),
 list:d=>ipcRenderer.invoke('list',d),read:(a,s,l)=>ipcRenderer.invoke('read',a,s,l),stat:a=>ipcRenderer.invoke('stat',a),open:u=>ipcRenderer.invoke('open',u),
 webOpen:(t,b)=>ipcRenderer.invoke('web:open',t,b),webNav:a=>ipcRenderer.invoke('web:nav',a),webBounds:b=>ipcRenderer.invoke('web:bounds',b),webClose:()=>ipcRenderer.invoke('web:close'),
 onWeb:cb=>{ipcRenderer.removeAllListeners('web:event');if(cb)ipcRenderer.on('web:event',(e,m)=>cb(m))},
 fileUrl:a=>'glfile://local/'+b64(a)+'/'+encodeURIComponent(a.split(/[\\/]/).pop()),
 cdn:'glcdn://cdn/stable/data/'});
