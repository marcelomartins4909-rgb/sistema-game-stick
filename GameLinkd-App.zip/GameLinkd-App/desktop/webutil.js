// Funções puras do navegador integrado (testadas em Node, sem depender do Electron).
function parseUrl(u){try{const x=new URL(u);return(x.protocol==='http:'||x.protocol==='https:')&&x.hostname?x:null}catch(e){return null}}
// Transforma o que o usuário digitou em um endereço http(s) ou em uma pesquisa. Bloqueia file:, javascript:, data:, app:, etc.
function normalizeInput(s,search){s=String(s==null?'':s).trim();if(!s)return null;
 if(/^https?:\/\//i.test(s))return parseUrl(s)?s:null;
 if(/^[a-z][a-z0-9+.-]*:/i.test(s)&&!/^[\w.-]+:\d+(\/|$)/.test(s))return null;
 if(/^[\w-]+(\.[\w-]+)+(:\d+)?([\/?#]\S*)?$/.test(s)||/^localhost(:\d+)?([\/?#]\S*)?$/.test(s))return 'https://'+s;
 return(search||'https://duckduckgo.com/?q=')+encodeURIComponent(s)}
// Traduz códigos de erro de rede do Chromium em mensagens compreensíveis.
function describeError(code,desc){const d=desc||'';
 if(code<=-200&&code>=-299)return{kind:'cert',msg:'O certificado de segurança deste site é inválido ('+d+'). Por segurança, o Game Linkd não abre sites com certificado inválido.'};
 const M={'-105':['dns','Endereço não encontrado. Confira se foi digitado corretamente.'],'-106':['offline','Sem conexão com a internet.'],'-102':['refused','O site recusou a conexão.'],'-109':['unreachable','O endereço não pôde ser alcançado.'],'-7':['timeout','O site demorou demais para responder.'],'-118':['timeout','O site demorou demais para responder.'],'-101':['reset','A conexão foi interrompida pelo site.'],'-100':['reset','A conexão foi encerrada.'],'-21':['network','A rede mudou durante o carregamento. Tente de novo.'],'-501':['insecure','A conexão não é segura.'],'-324':['empty','O site não enviou resposta.'],'-310':['redirects','Redirecionamentos demais.']};
 const m=M[String(code)];return m?{kind:m[0],msg:m[1]}:{kind:'other',msg:'Não foi possível carregar a página (código '+code+(d?': '+d:'')+').'}}
module.exports={parseUrl,normalizeInput,describeError};
