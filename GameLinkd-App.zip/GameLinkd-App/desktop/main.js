const{app,BrowserWindow,WebContentsView,session,protocol,net,ipcMain,dialog,shell}=require('electron');
const path=require('path'),fs=require('fs'),{pathToFileURL}=require('url'),U=require('./fsutil'),W=require('./webutil');
const priv={standard:true,secure:true,supportFetchAPI:true,corsEnabled:true,stream:true};
protocol.registerSchemesAsPrivileged(['app','glfile','glcdn'].map(scheme=>({scheme,privileges:priv})));
const PORT=process.env.PORTABLE_EXECUTABLE_DIR;           // definido pela versão portátil
if(PORT)app.setPath('userData',path.join(PORT,'Dados'));  // modo portátil: dados ao lado do .exe
if(!app.requestSingleInstanceLock())app.quit();
let win,wv=null;const roots=new Set(),rf=()=>path.join(app.getPath('userData'),'roots.json');
const loadRoots=()=>{try{JSON.parse(fs.readFileSync(rf(),'utf8')).forEach(r=>roots.add(r))}catch(e){}};
const addRoot=d=>{d=path.resolve(d);roots.add(d);try{fs.mkdirSync(path.dirname(rf()),{recursive:true});fs.writeFileSync(rf(),JSON.stringify([...roots]))}catch(e){}return d};
const okPath=p=>{p=path.resolve(p);for(const r of roots)if(p===r||p.startsWith(r+path.sep))return true;return false};
const denied=()=>{throw new Error('Pasta não autorizada. Selecione-a novamente.')};
// Só a interface do próprio Game Linkd (app://) pode usar a ponte. Páginas externas e jogos nunca têm acesso.
const trusted=e=>{if(!e.senderFrame||!String(e.senderFrame.url).startsWith('app://'))throw new Error('Origem não autorizada')};
const H=(ch,fn)=>ipcMain.handle(ch,(e,...a)=>{trusted(e);return fn(e,...a)});
const baseDir=()=>{const docs=path.join(app.getPath('documents'),'Game Linkd');const b=U.findBase([PORT,path.dirname(process.execPath),docs])||PORT||docs;try{U.ensureStructure(b)}catch(e){}return addRoot(b)};
const abrir=async p=>{const e=await shell.openPath(p);if(e)throw new Error(e);return true};
H('pickDir',async()=>{const r=await dialog.showOpenDialog({properties:['openDirectory']});return r.canceled||!r.filePaths[0]?null:addRoot(r.filePaths[0])});
H('romsDefault',()=>baseDir());
H('openRoms',()=>abrir(path.join(baseDir(),'ROMs')));H('openBase',()=>abrir(baseDir()));H('openDownloads',()=>abrir(app.getPath('downloads')));
H('allow',(e,d)=>okPath(d));
H('list',(e,d)=>{if(!okPath(d))denied();return U.listRoot(d)});
H('read',(e,a,s,l)=>{if(!okPath(a))denied();return U.readRange(a,s,Math.min(l,64*1048576))});
H('stat',(e,a)=>{if(!okPath(a))denied();return{size:fs.statSync(a).size}});
H('open',(e,u)=>{if(W.parseUrl(u))shell.openExternal(u)});
// ---------- Navegador integrado (Internet) ----------
// Usa o motor do Chromium do Electron em uma visão SEPARADA da interface: sem ponte, sem Node, com sessão própria e isolada.
const send=m=>{if(win&&!win.isDestroyed())win.webContents.send('web:event',m)};
function webSession(){const s=session.fromPartition('persist:gl-web');if(!s.__gl){s.__gl=true;s.setPermissionRequestHandler((wc,p,cb)=>cb(false));s.setPermissionCheckHandler(()=>false);s.on('will-download',e=>{e.preventDefault();send({type:'blocked',msg:'Downloads estão desativados no navegador integrado, por segurança.'})})}return s}
const setB=b=>{if(!wv)return;if(!b){wv.setVisible(false);return}wv.setBounds({x:Math.round(b.x),y:Math.round(b.y),width:Math.max(1,Math.round(b.w)),height:Math.max(1,Math.round(b.h))});wv.setVisible(true)};
function webClose(){if(!wv)return;try{win.contentView.removeChildView(wv)}catch(e){}try{wv.webContents.close({waitForBeforeUnload:false})}catch(e){}wv=null}
function webCreate(){wv=new WebContentsView({webPreferences:{session:webSession(),sandbox:true,contextIsolation:true,nodeIntegration:false,webSecurity:true,allowRunningInsecureContent:false}});win.contentView.addChildView(wv);const wc=wv.webContents;
 wc.setWindowOpenHandler(({url})=>{if(W.parseUrl(url))wc.loadURL(url);return{action:'deny'}});
 wc.on('will-navigate',(ev,nu)=>{if(!W.parseUrl(nu))ev.preventDefault()});
 const st=()=>send({type:'state',url:wc.getURL(),title:wc.getTitle(),loading:wc.isLoading(),canBack:wc.navigationHistory.canGoBack(),canFwd:wc.navigationHistory.canGoForward()});
 ['did-start-loading','did-stop-loading','did-navigate','did-navigate-in-page','page-title-updated'].forEach(ev=>wc.on(ev,st));
 wc.on('did-fail-load',(ev,code,desc,vurl,main)=>{if(main&&code!==-3)send(Object.assign({type:'error',url:vurl},W.describeError(code,desc)))});
 wc.on('render-process-gone',()=>send({type:'error',kind:'crash',msg:'A página parou de responder. Feche ou tente de novo.'}));
 wc.on('before-input-event',(ev,i)=>{if(i.type==='keyDown'&&i.key==='F9'){send({type:'close-request'});ev.preventDefault()}})}
H('web:open',(e,txt,b)=>{const href=W.normalizeInput(txt);if(!href)throw new Error('Endereço inválido. Só são permitidos sites http e https.');if(!wv)webCreate();setB(b);wv.webContents.loadURL(href);return href});
H('web:nav',(e,a)=>{if(!wv)return;const h=wv.webContents.navigationHistory;if(a==='back'&&h.canGoBack())h.goBack();else if(a==='forward'&&h.canGoForward())h.goForward();else if(a==='reload')wv.webContents.reload();else if(a==='stop')wv.webContents.stop()});
H('web:bounds',(e,b)=>setB(b));H('web:close',()=>webClose());
const CORS={'Access-Control-Allow-Origin':'*'},MT={'.js':'application/javascript','.mjs':'application/javascript','.css':'text/css','.html':'text/html','.json':'application/json','.wasm':'application/wasm','.png':'image/png','.svg':'image/svg+xml','.data':'application/octet-stream'};
const EXT_OK=new Set(Object.keys(MT)),MAX_CDN=300*1048576;
app.whenReady().then(()=>{loadRoots();
 protocol.handle('app',req=>{let p=decodeURIComponent(new URL(req.url).pathname);if(p==='/'||!p)p='/index.html';const base=path.join(__dirname,'app'),f=path.join(base,p);if(!f.startsWith(base+path.sep))return new Response('Negado',{status:403});return net.fetch(pathToFileURL(f).toString())});
 protocol.handle('glfile',async req=>{try{const seg=new URL(req.url).pathname.split('/')[1],abs=Buffer.from(seg.replace(/-/g,'+').replace(/_/g,'/'),'base64').toString('utf8');if(!okPath(abs))return new Response('Acesso negado',{status:403});const r=await net.fetch(pathToFileURL(abs).toString());return new Response(r.body,{status:r.status,headers:{...CORS,'Content-Type':'application/octet-stream'}})}catch(e){return new Response('Erro: '+e.message,{status:500})}});
 // Emulador (EmulatorJS): só aceita arquivos de cdn.emulatorjs.org/stable/data/ com extensões esperadas; guarda em cache local.
 protocol.handle('glcdn',async req=>{try{const rel=decodeURIComponent(new URL(req.url).pathname.replace(/^\//,'')),ext=path.extname(rel).toLowerCase();
  if(!/^stable\/data\//.test(rel)||rel.includes('..')||!EXT_OK.has(ext))return new Response('Recurso não permitido',{status:403});
  const dir=path.join(app.getPath('userData'),'ejs-cache'),f=path.join(dir,...rel.split('/').map(s=>s.replace(/[<>:"|?*]/g,'_')));if(!f.startsWith(dir+path.sep))return new Response('Negado',{status:403});
  const Hd={...CORS,'Content-Type':MT[ext]};try{return new Response(await fs.promises.readFile(f),{headers:Hd})}catch(e){}
  const r=await net.fetch('https://cdn.emulatorjs.org/'+rel);if(!r.ok)return new Response('Falha ao baixar o emulador (HTTP '+r.status+')',{status:r.status});
  const buf=Buffer.from(await r.arrayBuffer());if(buf.length>MAX_CDN)return new Response('Arquivo grande demais',{status:413});
  await fs.promises.mkdir(path.dirname(f),{recursive:true});await fs.promises.writeFile(f,buf);return new Response(buf,{headers:Hd})}
  catch(e){return new Response('Emulador indisponível offline: '+e.message,{status:503})}});
 win=new BrowserWindow({width:1280,height:720,backgroundColor:'#000000',autoHideMenuBar:true,title:'Game Linkd',webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true,webviewTag:false}});
 win.setMenu(null);win.loadURL('app://local/index.html');
 win.webContents.setWindowOpenHandler(({url})=>{if(W.parseUrl(url))shell.openExternal(url);return{action:'deny'}});
 win.webContents.on('will-navigate',(e,u)=>{if(!u.startsWith('app://'))e.preventDefault()});
 win.webContents.on('before-input-event',(e,i)=>{if(i.type==='keyDown'&&i.key==='F11'){win.setFullScreen(!win.isFullScreen());e.preventDefault()}});
 win.on('closed',()=>{wv=null})});
app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.focus()}});
app.on('window-all-closed',()=>app.quit());
