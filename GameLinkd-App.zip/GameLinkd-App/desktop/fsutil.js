// Funções de arquivo sem dependência do Electron (testáveis em Node puro).
const fs=require('fs'),path=require('path');
function walk(dir,base,out,depth){if(depth>14)return;let es;try{es=fs.readdirSync(dir,{withFileTypes:true})}catch(e){return}
 for(const e of es){const a=path.join(dir,e.name);if(e.isDirectory())walk(a,base,out,depth+1);else if(e.isFile()){try{const s=fs.statSync(a);out.push({rel:path.relative(base,a).split(path.sep).join('/'),abs:a,size:s.size,mtime:s.mtimeMs,name:e.name})}catch(x){}}}}
function hasSub(dir,n){try{return fs.readdirSync(dir,{withFileTypes:true}).find(e=>e.isDirectory()&&e.name.toLowerCase()===n)||null}catch(e){return null}}
// Se a pasta tem "ROMs", varre só ROMs e Capas (ignora Dados etc.). Senão varre a pasta inteira.
function listRoot(dir){const out=[];if(hasSub(dir,'roms')){for(const n of['roms','capas']){const s=hasSub(dir,n);if(s)walk(path.join(dir,s.name),dir,out,0)}}else walk(dir,dir,out,0);return out}
function findBase(cands){for(const d of cands){if(d&&hasSub(d,'roms'))return path.resolve(d)}return null}
async function readRange(abs,start,len){const fh=await fs.promises.open(abs,'r');try{const b=Buffer.alloc(len);const r=await fh.read(b,0,len,start);return b.subarray(0,r.bytesRead)}finally{await fh.close()}}
module.exports={walk,listRoot,findBase,readRange};

// ---- Estrutura de pastas do Game Linkd (só cria o que falta; nunca apaga nem sobrescreve) ----
const SUBS=['Nintendo 64','Game Boy','Game Boy Color','Game Boy Advance','Nintendo DS','NES','Super Nintendo','Master System','Mega Drive','Game Gear','Sega CD','Sega 32X','Sega Saturn','PC Engine','Neo Geo','Neo Geo Pocket','Atari 2600','Atari 7800','PlayStation','Arcade','Outros'];
const MANUAL=`GAME LINKD - COMO ADICIONAR SEUS JOGOS

1. Copie seus arquivos de jogos (ROMs) para a pasta "ROMs" que fica ao lado desta pasta "Manual".
   Pode colocar soltos ou dentro das subpastas por console (Nintendo 64, Game Boy Advance, PlayStation...).
   Se colocar na pasta errada, o Game Linkd tenta reconhecer o console pelo conteudo do arquivo.
2. Abra o Game Linkd e clique em "Procurar novos jogos".
3. Escolha um jogo na biblioteca. So roda se existir um emulador integrado para aquele console.
   Alguns consoles precisam de BIOS, que voce mesmo deve fornecer.

Jogos de CD (PlayStation, Sega CD, Saturn): copie o arquivo .cue junto com os .bin dele, na mesma pasta.
Capas: coloque imagens (.jpg ou .png) na pasta "Capas" com o MESMO nome do jogo (ex.: Sonic.jpg).
O Game Linkd nunca apaga nem move seus arquivos.
`;
function ensureStructure(base){const made=[];const mk=d=>{if(!fs.existsSync(d)){fs.mkdirSync(d,{recursive:true});made.push(d)}};
 mk(base);mk(path.join(base,'ROMs'));SUBS.forEach(s=>mk(path.join(base,'ROMs',s)));mk(path.join(base,'Capas'));mk(path.join(base,'Manual'));
 const m=path.join(base,'Manual','LEIA-ME.txt');if(!fs.existsSync(m)){fs.writeFileSync(m,MANUAL);made.push(m)}return made}
module.exports.ensureStructure=ensureStructure;module.exports.SUBS=SUBS;
