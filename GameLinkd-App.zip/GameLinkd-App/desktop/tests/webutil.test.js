const test=require('node:test'),assert=require('node:assert'),W=require('../webutil');
test('aceita só http(s)',()=>{assert.ok(W.parseUrl('https://exemplo.com/a?b=1'));assert.ok(W.parseUrl('http://exemplo.com'));for(const u of['file:///C:/x','javascript:alert(1)','data:text/html,<b>x</b>','app://local/index.html','glfile://x/y','ftp://a.com','','lixo'])assert.strictEqual(W.parseUrl(u),null,u)});
test('normaliza endereços, pesquisas e bloqueia esquemas perigosos',()=>{
 assert.strictEqual(W.normalizeInput('exemplo.com'),'https://exemplo.com');assert.strictEqual(W.normalizeInput('  www.exemplo.com/p?q=1 '),'https://www.exemplo.com/p?q=1');
 assert.strictEqual(W.normalizeInput('localhost:3000/x'),'https://localhost:3000/x');assert.strictEqual(W.normalizeInput('https://a.com/x'),'https://a.com/x');
 assert.strictEqual(W.normalizeInput('gatos fofos'),'https://duckduckgo.com/?q=gatos%20fofos');assert.strictEqual(W.normalizeInput('x','https://s.com/?q='),'https://s.com/?q=x');
 for(const u of['javascript:alert(1)','file:///etc/passwd','data:text/html;base64,AAAA','app://local/index.html','glfile://x','vbscript:x','http://'])assert.strictEqual(W.normalizeInput(u),null,u);
 assert.strictEqual(W.normalizeInput(''),null);assert.strictEqual(W.normalizeInput(null),null)});
test('mensagens de erro compreensíveis',()=>{assert.strictEqual(W.describeError(-105,'ERR_NAME_NOT_RESOLVED').kind,'dns');assert.strictEqual(W.describeError(-106,'').kind,'offline');assert.strictEqual(W.describeError(-202,'ERR_CERT_AUTHORITY_INVALID').kind,'cert');assert.match(W.describeError(-202,'x').msg,/certificado/i);assert.strictEqual(W.describeError(-118,'').kind,'timeout');assert.match(W.describeError(-999,'ERR_X').msg,/-999/)});
