#!/usr/bin/env node
// Auditoria estática do que será empacotado: padrões de código arriscados, extensões suspeitas, dependências e endereços externos.
// Sai com código 1 se encontrar algo proibido. Uso: node scripts/audit.js
const fs=require('fs'),path=require('path');
const raiz=path.join(__dirname,'..'),alvos=['app','desktop','android-app/native','scripts','site'];
const IGN=new Set(['node_modules','dist','www','android']);
const PROIBIDOS=[[/\beval\s*\(/,'eval()'],[/new\s+Function\s*\(/,'new Function()'],[/child_process/,'child_process'],[/\bexecSync?\s*\(/,'exec()'],[/document\.write\s*\(/,'document.write()'],[/\bspawn\s*\(/,'spawn()'],[/powershell/i,'powershell'],[/nodeIntegration\s*:\s*true/,'nodeIntegration: true'],[/webSecurity\s*:\s*false/,'webSecurity: false'],[/ignore-certificate-errors|allowRunningInsecureContent\s*:\s*true/,'certificados/conteúdo inseguro permitidos']];
const EXT_SUSPEITAS=/\.(exe|dll|bat|cmd|ps1|vbs|scr|msi|jar|so|dylib|bin)$/i;
const achados=[],arquivos=[],hosts=new Map();let b64=0,b64Bytes=0;
function varre(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(IGN.has(e.name))continue;const p=path.join(d,e.name);if(e.isDirectory()){varre(p);continue}
 const rel=path.relative(raiz,p),st=fs.statSync(p);arquivos.push([rel,st.size]);if(EXT_SUSPEITAS.test(e.name))achados.push(rel+': extensão executável/binária inesperada no código-fonte');
 if(!/\.(js|html|java|py|json|yml|md|txt)$/i.test(e.name))continue;const t=fs.readFileSync(p,'utf8');
 if(!/audit\.js$/.test(rel))for(const[re,nome]of PROIBIDOS)if(re.test(t))achados.push(rel+': usa '+nome);
 for(const m of t.matchAll(/https?:\/\/([a-z0-9.-]+)/gi)){const h=m[1].toLowerCase();hosts.set(h,(hosts.get(h)||0)+1)}
 if(/\.html$/.test(rel))for(const m of t.matchAll(/data:[a-z/+.-]+;base64,[A-Za-z0-9+/=]{200,}/g)){b64++;b64Bytes+=m[0].length}}}
for(const a of alvos)if(fs.existsSync(path.join(raiz,a)))varre(path.join(raiz,a));
const pk=JSON.parse(fs.readFileSync(path.join(raiz,'desktop/package.json'),'utf8')),pa=JSON.parse(fs.readFileSync(path.join(raiz,'android-app/package.json'),'utf8'));
console.log('== Dependências (desktop) ==\n  em tempo de execução (vão dentro do app):',Object.keys(pk.dependencies||{}).length?Object.keys(pk.dependencies).join(', '):'nenhuma','\n  só de compilação:',Object.keys(pk.devDependencies).join(', '));
console.log('== Dependências (android) ==\n  ',Object.keys(pa.dependencies).concat(Object.keys(pa.devDependencies)).join(', '));
console.log('== Scripts npm (ganchos de instalação são suspeitos) ==\n  ',Object.keys(pk.scripts).join(', '),'| ganchos preinstall/install/postinstall:',['preinstall','install','postinstall'].filter(k=>pk.scripts[k]||pa.scripts&&pa.scripts[k]).join(', ')||'nenhum');
if(['preinstall','install','postinstall'].some(k=>pk.scripts[k]))achados.push('desktop/package.json: gancho de instalação (preinstall/install/postinstall)');
console.log('== Arquivos analisados:',arquivos.length,'| maiores:',arquivos.sort((a,b)=>b[1]-a[1]).slice(0,3).map(a=>a[0]+' ('+Math.round(a[1]/1024)+' KB)').join(', '));
console.log('== Imagens embutidas (data URI) no HTML:',b64,'=',Math.round(b64Bytes/1024),'KB (capas e avatares enviados por você)');
console.log('== Endereços externos referenciados no código ==\n  ',[...hosts.entries()].sort((a,b)=>b[1]-a[1]).map(([h,n])=>h+' ('+n+')').join(', '));
console.log(achados.length?'\n== PROBLEMAS ENCONTRADOS ==\n  '+achados.join('\n  '):'\n== Nenhum padrão proibido encontrado ==');
process.exit(achados.length?1:0);
