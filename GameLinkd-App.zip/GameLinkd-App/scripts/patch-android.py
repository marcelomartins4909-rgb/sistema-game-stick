#!/usr/bin/env python3
"""Aplica as personalizações do Game Linkd no projeto Android gerado pelo Capacitor.
Executar dentro de android-app/ depois de `npx cap add android`. Pode ser repetido sem efeito colateral."""
import os, re, shutil, sys

root = os.path.join(os.getcwd(), "android")
pkg_dir = os.path.join(root, "app", "src", "main", "java", "com", "gamelinkd", "app")
manifest = os.path.join(root, "app", "src", "main", "AndroidManifest.xml")
gradle = os.path.join(root, "app", "build.gradle")

def fail(msg):
    print("ERRO:", msg); sys.exit(1)

if not os.path.isdir(root): fail("pasta android/ não encontrada (rode `npx cap add android` antes)")
os.makedirs(pkg_dir, exist_ok=True)
for f in ("SafPlugin.java", "MainActivity.java"):
    shutil.copyfile(os.path.join("native", f), os.path.join(pkg_dir, f))   # sobrescreve a MainActivity padrão

# Manifesto: TV (Leanback) e telas sem toque
m = open(manifest, encoding="utf-8").read()
feat = ('    <uses-feature android:name="android.software.leanback" android:required="false" />\n'
        '    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />\n')
if "android.software.leanback" not in m:
    m = m.replace("<application", feat + "\n    <application", 1)
if "LEANBACK_LAUNCHER" not in m:
    m, n = re.subn(r'(<category android:name="android.intent.category.LAUNCHER"\s*/>)',
                   r'\1\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />', m, count=1)
    if n == 0: fail("não encontrei a categoria LAUNCHER no manifesto")
open(manifest, "w", encoding="utf-8").write(m)

# Dependência do DocumentFile
g = open(gradle, encoding="utf-8").read()
if "androidx.documentfile" not in g:
    g, n = re.subn(r"dependencies\s*\{", "dependencies {\n    implementation 'androidx.documentfile:documentfile:1.0.1'", g, count=1)
    if n == 0: fail("bloco dependencies não encontrado em app/build.gradle")
# Assinatura de release: só se ANDROID_SIGNING=1. A chave vem de variáveis de ambiente (segredos do GitHub), nunca do repositório.
if os.environ.get("ANDROID_SIGNING") == "1" and "gamelinkd-signing" not in g:
    sign = """
    // gamelinkd-signing
    signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_FILE"))
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
"""
    g, n1 = re.subn(r"(\n[ \t]*)buildTypes\s*\{", lambda m: sign + m.group(1) + "buildTypes {", g, count=1)
    g, n2 = re.subn(r"(buildTypes\s*\{\s*release\s*\{)", r"\1\n            signingConfig signingConfigs.release", g, count=1)
    if n1 == 0 or n2 == 0: fail("não consegui configurar a assinatura em app/build.gradle (bloco buildTypes/release não encontrado)")
open(gradle, "w", encoding="utf-8").write(g)
print("Projeto Android personalizado com sucesso.")
