// Copia a interface (app/) para a pasta de cada plataforma antes de compilar.
const fs=require('fs'),path=require('path');
const alvo=process.argv[2],raiz=path.join(__dirname,'..');
const destino={desktop:path.join(raiz,'desktop','app'),android:path.join(raiz,'android-app','www')}[alvo];
if(!destino){console.error('Uso: node scripts/prepare.js desktop|android');process.exit(1)}
fs.rmSync(destino,{recursive:true,force:true});
fs.cpSync(path.join(raiz,'app'),destino,{recursive:true});
console.log('Interface copiada para',destino);
