# Game Linkd — aplicativo instalável (Windows e Android)

> **Estado real deste projeto:** é o código-fonte completo e o fluxo de compilação. **Nenhum `.exe` nem `.apk` foi gerado ainda**,
> e eu (o assistente que escreveu isto) **não consegui compilar nem rodar o app nativo**. O que foi testado está na seção "O que foi testado".
> A primeira compilação pode apresentar erros: se acontecer, copie a mensagem do log e envie para correção.

## 1. Como gerar o instalador e o APK (sem programar)

1. Crie uma conta gratuita em **github.com** e clique em **New repository** (pode ser privado).
2. Extraia este .zip. Na página do repositório: **Add file → Upload files** e arraste **todas as pastas e arquivos**,
   inclusive a pasta oculta **`.github`** (no Windows, ative "Itens ocultos" no Explorador para vê-la). Clique em **Commit changes**.
3. Abra a aba **Actions**. Se pedir, clique em habilitar. Escolha **Compilar Game Linkd → Run workflow**.
4. Espere uns 10 a 20 minutos. Quando terminar com ✔ verde, há duas formas de baixar:
   - **Mais fácil (links diretos, sem login):** na página principal do repositório, clique em **Releases** (coluna da direita) → a versão mais nova → em **Assets**, clique no arquivo `.exe` ou `.apk`.
   - **Alternativa:** abra a execução concluída e baixe, em **Artifacts**:
   - **GameLinkd-Windows**: `GameLinkd-Setup-1.0.0.exe` (instalador) e `GameLinkd-Portatil-1.0.0.exe` (versão portátil).
   - **GameLinkd-Android**: `app-debug.apk`.
5. Se um dos dois falhar (marca vermelha), abra o passo que falhou, copie o texto do erro e me envie.

## 2. Windows

- **Instalador:** execute `GameLinkd-Setup`, escolha a pasta, e abra pelo atalho. O Windows pode mostrar o aviso "SmartScreen" porque o programa não é assinado: clique em *Mais informações → Executar assim mesmo*.
- **Portátil (recomendado para o seu uso):** crie a pasta

```
Game Linkd/
├── GameLinkd-Portatil-1.0.0.exe
├── ROMs/        (coloque suas ROMs aqui, em subpastas ou soltas)
├── Capas/       (opcional: Nome do Jogo.jpg)
└── Dados/       (criada sozinha: biblioteca, favoritos, configurações)
```
  Ao abrir, o programa procura a pasta `ROMs` ao lado do `.exe` e monta a biblioteca sozinho. Ao reabrir, só mostra aviso se houver novidades.
  No instalador, a pasta `ROMs` é procurada ao lado do programa e em `Documentos\Game Linkd\ROMs`; você também pode escolher outra com **SELECIONAR PASTA DE ROMs**.
- Os dados da versão instalada ficam em `%APPDATA%\Game Linkd`.

## 3. Android / TV box

- Copie `app-debug.apk` para a TV box (pendrive, ou envie por um app de transferência) e abra pelo gerenciador de arquivos.
  É preciso permitir "instalar de fontes desconhecidas" para esse gerenciador.
- Abra o **Game Linkd** → **Meus Jogos** → **SELECIONAR PASTA DE ROMs**. Aparece o seletor de pastas do próprio Android: escolha a pasta e toque em **Usar esta pasta**.
  O Android guarda a permissão (somente leitura). Se ela se perder, o app pede a pasta de novo.
- Requisitos: Android 5.1 ou mais novo, com o componente "Android System WebView" atualizado. Não foi verificada compatibilidade com processadores específicos.
- O APK é "debug" (assinado com chave de teste). Serve para instalar direto, não para a Play Store.

## 4. Emuladores: o que existe e o que não existe

O Game Linkd usa o **EmulatorJS** (emuladores compilados para WebAssembly).

| Console | Situação |
|---|---|
| NES, SNES, N64, Game Boy/Color, GBA, Nintendo DS, Master System, Mega Drive, Game Gear, Sega CD, 32X, Saturn, PC Engine, Neo Geo Pocket, Atari 2600/7800, PlayStation 1, Arcade | Configurados, **ainda não testados executando jogos de verdade** |
| PS2, Dreamcast, PSP, Atari Lynx, ScummVM | **Sem emulador integrado.** Aparecem na biblioteca como "sem emulador" |

- **Windows:** os arquivos do emulador são baixados da internet **na primeira vez que cada console é usado** e ficam guardados em `Dados\ejs-cache`. Depois disso funcionam sem internet, mas só para os consoles que já foram abertos uma vez.
- **Android:** o emulador é carregado da internet sempre; o cache do WebView pode ajudar, mas **não é garantido funcionar offline**.
- **ROMs no Android** são lidas inteiras para a memória antes de iniciar. Arquivos muito grandes (imagens de CD acima de algumas centenas de MB) podem falhar em TV boxes com pouca memória.
- **BIOS:** não vem incluída. PS1, Sega CD, Saturn e Neo Geo podem exigir BIOS que você mesmo deve fornecer.
- **Licenças:** confira as licenças do EmulatorJS e dos emuladores que ele usa (o EmulatorJS é publicado sob GPL; distribuir binários com ele exige cumprir essa licença). Não distribua BIOS nem jogos protegidos.

## 5. O que foi testado e o que não foi

**Testado (em navegador de teste, com o código real do app e uma ponte simulada para o sistema de arquivos):**
busca automática ao abrir, identificação de 10 jogos por conteúdo (N64, GBA, DS, PS1 com .cue/.bin, PS2, Mega Drive, Lynx, arcade, desconhecido), duplicado e arquivo corrompido ignorados, capas da pasta `Capas`, pasta `Dados` ignorada, aviso silencioso quando nada mudou, jogo apontando para o arquivo local e para o emulador em cache, leitura do arquivo depois de reiniciar, abertura de sites fora do app.
Também: a sintaxe dos arquivos JS, o YAML do fluxo e o script que personaliza o projeto Android (rodado duas vezes sobre um esqueleto simulado).

**Não testado (precisa de você):**
- Compilar o instalador `.exe` e o `.apk`.
- Abrir o app Electron de verdade (janela, protocolos `app://`, `glfile://`, `glcdn://`, cache do emulador).
- O plugin Java `SafPlugin` (seletor de pasta do Android) e o registro dele no `MainActivity`.
- A leitura de arquivos por intervalo no Android e a execução de qualquer jogo.
- Controle remoto e gamepad dentro do app nativo (a interface já usa a Gamepad API e as setas do teclado).
- Instalação e desinstalação.

## 6. O que ainda não existe

- Emuladores nativos para PS2, Dreamcast e PSP (exigem outro trabalho por plataforma e hardware compatível).
- Atualização automática do aplicativo.
- Banner de TV (ícone na tela inicial da Android TV pode aparecer sem imagem própria).
- Grupos de discos múltiplos e extração de ZIP.
- No navegador interno, sites que proíbem ser exibidos dentro de outros (como YouTube) continuam em branco com aviso. Trocar o iframe por uma janela de navegador própria do Electron resolveria isso no Windows; fica como próximo passo.

## 7. Estrutura

```
app/            interface (HTML) — a mesma nas duas versões; native.js liga ao sistema de arquivos
desktop/        Windows (Electron): main.js, preload.js, fsutil.js, package.json
android-app/    Android (Capacitor): config, plugin Java (native/) e dependências
scripts/        prepare.js (copia a interface) e patch-android.py (personaliza o projeto Android)
.github/workflows/build.yml   compilação automática no GitHub
```

Para compilar no seu computador: `node scripts/prepare.js desktop`, depois `cd desktop && npm install && npm run dist` (Windows, Node 20).
Para Android é necessário Java 17 e Android SDK: veja os passos do arquivo `.github/workflows/build.yml`.

## 8. Pasta de ROMs, assistente e tela de download (novidades)

- **Windows:** na primeira abertura o programa cria `ROMs` (com 21 subpastas por console), `Capas` e `Manual`.
  Versão portátil: ao lado do `.exe`. Versão instalada: em `Documentos\Game Linkd`. Nada é apagado nem sobrescrito.
- **Botões** (Início, Meus Jogos e Ajustes): **ABRIR PASTA DE ROMs**, **Procurar novos jogos**, **Como adicionar meus jogos?**; em Ajustes também **Abrir pasta do Game Linkd**, **Baixar e instalar** e **Meus downloads**.
  Ao voltar da pasta de ROMs, o Windows procura novos jogos sozinho. ROMs em pasta errada são reconhecidas pelo conteúdo e **não são movidas**.
- **Android:** o app não abre pastas do sistema; o botão explica e leva ao seletor de pastas do Android.
- **Assistente "Bem-vindo ao Game Linkd"** (4 etapas) aparece na primeira vez e pode ser pulado ou revisto em Ajustes.
- **Baixar e instalar:** consulta a página de Releases do seu repositório pela API pública do GitHub. Em Ajustes → Baixar e instalar → *Configurar endereço*, digite `seunome/seu-repositorio`
  (ou preencha `REL_DEFAULT` no início do bloco de script de `app/index.html`). Sem repositório ou sem release, mostra "Esta versão ainda não possui um instalador publicado."

**Testado nesta etapa** (navegador de teste + código real de pastas): criação da estrutura, 1ª inicialização sem ROMs, assistente, botões, detecção em subpastas e em pasta errada, duplicado, persistência ao reabrir, tela de download sem release e com um release **simulado**, texto do Android.
**Não testado:** abrir a pasta no Explorador de Arquivos de verdade, instalação em outro computador, o fluxo no Android real, o job `publicar` do GitHub (criação da Release), e qualquer jogo executando.

## 9. Se o Windows bloquear o programa ("Controle de Aplicativo Inteligente")

O instalador e o `.exe` portátil **não são assinados digitalmente** (assinatura exige um certificado pago). O Controle de Aplicativo Inteligente
(Smart App Control, do Windows 11) bloqueia programas sem assinatura e **não oferece botão "executar assim mesmo"**. Opções:

1. **Usar a versão HTML no Edge ou Chrome (sem instalar nada):** abra o `gamelinkd.html` no navegador. Em Meus Jogos, **SELECIONAR PASTA DE ROMs** abre o seletor de pastas do navegador.
   Limitações: o emulador precisa de internet, e o navegador pede autorização da pasta de novo às vezes.
2. **Desativar o Controle de Aplicativo Inteligente:** Configurações → Privacidade e segurança → Segurança do Windows → Controle de aplicativos e navegador → Configurações do Controle de Aplicativo Inteligente → **Desativado**.
   Atenção: depois de desativado, **não dá para ligar de novo** sem reinstalar o Windows, e a proteção do computador diminui. Só faça isso se aceitar o risco.
3. **Assinar o aplicativo** (solução definitiva): com um certificado de assinatura de código (pago, ou o programa gratuito SignPath para projetos de código aberto), configurar a assinatura no `electron-builder`. Não está feito neste projeto.

## 10. Diagnóstico do bloqueio de download e instalação

**Causa identificada:** o instalador e o `.exe` portátil são gerados **sem assinatura digital** (não existe certificado configurado). No Windows 11 o
Controle de Aplicativo Inteligente bloqueia o que não é assinado e não tem reputação, e o SmartScreen pode avisar. O projeto é uma interface HTML empacotada
(Electron no Windows, Capacitor no Android); o problema não está no código da interface nem na estrutura do pacote.
**Isto foi confirmado pela mensagem que você relatou, não por teste local**: não há Windows nem pacotes gerados no ambiente onde o projeto foi escrito.

**O que foi verificado e o que não foi:** a configuração do `electron-builder`, os caminhos dos arquivos incluídos, os testes automatizados (`cd desktop && npm test`, 5 testes, passam), a sintaxe dos scripts,
o YAML dos fluxos e o script de assinatura do Android (em um `build.gradle` simulado). **Não foi possível** instalar dependências, compilar, instalar nem executar o programa (sem internet, Java, Gradle, NSIS ou Windows no ambiente).

### Assinatura digital (a solução permanente)
Os fluxos já suportam assinar, **sem guardar chaves no repositório**. No GitHub: *Settings → Secrets and variables → Actions → New repository secret*.

| Segredo | Para quê |
|---|---|
| `WIN_CSC_LINK` | certificado de assinatura de código `.pfx` em Base64 (ou endereço seguro dele) |
| `WIN_CSC_KEY_PASSWORD` | senha do certificado |
| `ANDROID_KEYSTORE_B64` | arquivo de chave do Android (`.keystore`) em Base64 |
| `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD` | dados da chave do Android |

- **Windows:** é preciso comprar um certificado de assinatura de código de uma autoridade reconhecida (ou usar um serviço como o SignPath, gratuito para código aberto, ou o Azure Trusted Signing; estes dois exigiriam adaptar o fluxo).
  Sem os segredos o fluxo gera arquivos **não assinados** e mostra um aviso. Mesmo assinado, um programa novo pode demorar a ganhar reputação junto ao SmartScreen.
- **Android:** guarde a chave `.keystore` em lugar seguro e **sempre use a mesma** nas próximas versões, senão o Android não atualiza por cima. Sem os segredos, o APK sai assinado com chave de teste (serve para instalar direto, não para distribuição pública).

### Verificação do download
- Cada compilação confere se foram gerados os dois `.exe` (instalador e portátil, mais de 20 MB) e o APK (mais de 1 MB, com `AndroidManifest.xml`), calcula o **SHA-256** e o publica na descrição da Release e no arquivo `SHA256SUMS.txt`.
- Para conferir o que você baixou, no PowerShell: `Get-FileHash .\GameLinkd-Setup-1.0.0.exe -Algorithm SHA256` e compare com o valor publicado. Baixe somente pela aba **Releases** do repositório.
- Se o Windows ou o navegador bloquear, **não ignore o aviso**: confira a origem e o SHA-256, veja se a descrição da Release diz "NÃO assinado" e só então decida. Não desative o antivírus.

### Publicação
- `build.yml`: roda ao clicar em **Run workflow**, ao criar uma tag `v*` ou em pull requests (estes só compilam, sem publicar). Gera artefatos Windows e Android separados e, nos dois primeiros casos, a Release.
- `pages.yml` publica a pasta `site/` como página de download no GitHub Pages. Ative em *Settings → Pages → Source: GitHub Actions*. A página descobre o repositório pelo endereço (`dono.github.io/repo`) ou por `?repo=dono/repo`, mostra só os arquivos realmente publicados e diz "em preparação" quando não há nenhum.
- **Nada foi publicado ainda.** Não existe Release nem página no ar até você rodar esses fluxos.

### Comandos
- Testes: `cd desktop && npm install && npm test`
- Windows (no Windows, Node 20): `node scripts/prepare.js desktop && cd desktop && npm install && npm run dist` → `desktop/dist/`
- Android (Java 17 + Android SDK): `node scripts/prepare.js android && cd android-app && npm install && npx cap add android && python3 ../scripts/patch-android.py && npx cap sync android && cd android && ./gradlew assembleDebug` → `android-app/android/app/build/outputs/apk/debug/`

## 11. Bloqueio "arquivo potencialmente perigoso": o que investigar (e o que precisa de você)

A causa **exata** do bloqueio mais recente **não pôde ser determinada** com as informações disponíveis: não se sabe qual arquivo foi bloqueado (o `.zip` do projeto, o instalador, o portátil ou o APK) nem qual componente bloqueou.
Para identificar, preciso que você anote e envie:
1. **O nome do arquivo** e de onde foi baixado (chat, GitHub Releases, outro link).
2. **Quem bloqueou e a frase exata na tela**: Microsoft Edge/Chrome ("não é baixado com frequência", "pode ser perigoso"), SmartScreen, Controle de Aplicativo Inteligente, Windows Defender/antivírus (qual).
3. No Edge: `edge://downloads` → o arquivo → o motivo exibido. No Windows: *Segurança do Windows → Proteção contra vírus e ameaças → Histórico de proteção* (nome da ameaça, se houver).
4. O SHA-256 do arquivo: `Get-FileHash .\arquivo -Algorithm SHA256`.
5. Se o Defender apontar uma ameaça pelo nome, o responsável pelo app pode pedir reanálise em https://www.microsoft.com/wdsi/filesubmission (falso positivo). Não desative o antivírus.

**O que foi verificado no projeto** (`node scripts/audit.js`, roda também no GitHub antes de compilar): nenhuma dependência dentro do app (só `electron` e `electron-builder` na compilação); nenhum gancho de instalação; nenhum `eval`, `new Function`, `child_process`, `exec`, `spawn`, `document.write`, `nodeIntegration`, `webSecurity: false` nem certificado ignorado; nenhum arquivo executável/binário no código-fonte;
endereços externos listados (jogos online, Wikipedia, GitHub, EmulatorJS). A única coisa que vem da internet e é executada é o emulador (EmulatorJS), que o programa baixa de `cdn.emulatorjs.org` na primeira vez de cada console.
Uma coisa que pode atrair desconfiança de ferramentas automáticas: o arquivo `app/index.html` é grande (≈ 680 KB, com 26 imagens embutidas) e o app baixa e executa o emulador em tempo de execução. Isso é legítimo, mas é um comportamento que um antivírus pode notar.
Também **não está assinado**, e programas novos não têm reputação; é o motivo mais comum para esse tipo de aviso.

**Endurecimentos feitos nesta versão** (Windows): janela com `sandbox` ativado e sem Node; a ponte com o sistema só responde à interface `app://` (nunca a páginas externas); o protocolo do emulador só aceita `stable/data/` do CDN, com extensões esperadas e limite de tamanho; proteção contra caminhos fora da pasta do app; instalador por usuário (sem pedir administrador) e dados preservados ao desinstalar.

## 12. Navegador integrado (Windows)

**Tecnologia:** Electron (`WebContentsView`, motor Chromium). Escolhido porque o projeto já usa Electron; trocar para Tauri exigiria reescrever a ponte e adicionar Rust, sem ganho para esta função.
Isso **ainda é um motor de renderização web**: não é um navegador independente de tecnologias web.

- A página abre numa **visão separada** da interface: sem ponte do Game Linkd, sem Node, `sandbox`, sessão própria (`persist:gl-web`, dados de navegação separados dos arquivos do app), permissões de câmera/microfone/localização negadas, downloads bloqueados, só `http` e `https`.
  Como não é um iframe, **sites como YouTube abrem normalmente** (não dependem de aceitarem ser incorporados).
- Erros de certificado **não são ignorados**: o site é recusado com mensagem. Erros de rede (DNS, sem internet, tempo esgotado etc.) mostram mensagem em português e as opções *Tentar de novo*, *Abrir externamente* e *Voltar ao Game Linkd*.
- Barra de endereço/pesquisa, voltar, avançar, atualizar, página inicial, indicador de carregamento e endereço atual. **F9** volta ao Game Linkd mesmo se a página travar; fechar o painel destrói a visão e libera os recursos.
- A pasta de ROMs **não é compartilhada** com as páginas: o acesso a arquivos só existe na interface do Game Linkd.
- **Limites:** dentro da página aberta, o controle/gamepad age como a própria página; para voltar use F9 ou o mouse. No **Android** esta função continua abrindo o site no navegador do sistema (não há navegador integrado, para não adicionar plugins não testados). Na versão HTML (navegador) continua o visualizador em iframe, que não abre sites que proíbem incorporação.

**Jogos de Navegador:** já existiam (importar HTML/ZIP/pasta, cadastrar por endereço, capa, categoria, salvar, remover, tela cheia, fechar e voltar). Rodam em área isolada (`sandbox` sem acesso à biblioteca), com os arquivos embutidos na página do jogo; jogos que dependem de servidor local, módulos ou `fetch` de arquivos locais podem não funcionar e o app avisa.

**Erro `script-src-elem`:** ocorre **só na página publicada/ambientes restritos**, porque a política de segurança do ambiente só permite scripts de alguns hosts; o app Windows não tem essa limitação (o emulador é servido por um protocolo próprio). Não foi desativada nenhuma política de segurança.
**Não foi testado**: o emulador executando um jogo de verdade.

## 13. Testes desta etapa
- Node: 8 testes (arquivos, estrutura de pastas, validação de endereços, mensagens de erro) — passam. `npm test` em `desktop/`.
- Interface (navegador de teste com ponte simulada): abrir/fechar o navegador integrado, enviar endereço e retângulo da visão, indicador de carregamento, voltar/avançar/atualizar, erro de certificado, endereço perigoso recusado, download bloqueado, F9 e Esc destroem a visão. Funcionou.
- Auditoria de segurança (`node scripts/audit.js`): sem padrões proibidos. Página de download: 6 cenários (sem repositório, 404, erro 500, sem rede, com hashes, só Windows).
- **Não testado:** compilar/instalar/abrir o programa, o `WebContentsView` real (carregar sites, certificados, bloqueio de downloads), o plugin Android, o fluxo de publicação no GitHub, desinstalação, controles de verdade.
