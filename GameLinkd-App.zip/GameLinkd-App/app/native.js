/* Ponte nativa do Game Linkd. No navegador comum este arquivo não faz nada.
   Desktop (Electron): window.glElectron. Android (Capacitor): plugin "Saf". */
(function(){
const E=window.glElectron,A=window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform()&&(Capacitor.Plugins&&Capacitor.Plugins.Saf||(Capacitor.registerPlugin&&Capacitor.registerPlugin('Saf')));
if(!E&&!A)return;
class NFile{constructor(n){this.name=n.name||String(n.rel).split('/').pop();this.size=n.size;this.uri=n.abs||n.uri;this.rel=n.rel;this.native=true;this.type='';this.lastModified=n.mtime||0}
 async rd(a,l){const r=await N.read(this.uri,a,l);return r.buffer?r.buffer.slice(r.byteOffset,r.byteOffset+r.byteLength):r}
 slice(a,b){const s=this,e=Math.min(b==null?s.size:b,s.size),l=Math.max(0,e-a);return{size:l,arrayBuffer:()=>s.rd(a,l),text:async()=>new TextDecoder().decode(await s.rd(a,l))}}
 arrayBuffer(){return this.rd(0,this.size)}
 async text(){return new TextDecoder().decode(await this.rd(0,this.size))}
 get url(){return N.url(this)}}
const sep=d=>d.includes('\\')?'\\':'/';
const N=E?{kind:'desktop',label:d=>d.split(/[\\/]/).filter(Boolean).pop()||d,pick:()=>E.pickDir(),def:()=>E.romsDefault(),
  list:async d=>{if(!await E.allow(d))throw new Error('Pasta não autorizada. Selecione-a novamente.');return E.list(d)},
  read:(f,a,l)=>E.read(f,a,l),open:u=>E.open(u),url:f=>E.fileUrl(f.uri),
  resolve:async(g,fi)=>{const r=g.root.slice(2),s=sep(r),abs=r.replace(/[\\/]$/,'')+s+fi.path.split('/').join(s),st=await E.stat(abs);return new NFile({abs,size:st.size,rel:fi.path})}}
 :{kind:'android',label:d=>{try{return decodeURIComponent(String(d).split('/').pop()).split(':').pop()||'ROMs'}catch(e){return'ROMs'}},pick:async()=>(await A.pickTree()).uri,def:async()=>null,
  list:async d=>(await A.list({tree:d})).files,
  read:async(u,a,l)=>{const r=await A.read({uri:u,offset:a,length:l}),b=atob(r.data),o=new Uint8Array(b.length);for(let i=0;i<b.length;i++)o[i]=b.charCodeAt(i);return o},
  open:u=>window.open(u,'_blank'),url:null,
  resolve:async(g,fi)=>{if(!fi.uri)throw new Error('sem uri');await N.read(fi.uri,0,1);return new NFile({uri:fi.uri,size:fi.size,rel:fi.path})}};
window.GLNATIVE=N.kind;if(E)window.EJSBASE=E.cdn;
async function scanNative(dir,silent){const L=await N.list(dir);return runScan({name:N.label(dir),rootId:'n:'+dir,silent:!!silent,items:L.map(x=>({f:new NFile(x),path:x.rel}))})}
window.pickRoms=()=>{N.pick().then(d=>d&&scanNative(d)).catch(e=>{if(!/cancel/i.test(String(e&&e.message)))toast('Não foi possível abrir a pasta: '+((e&&e.message)||e))})};
window.rescanRoms=async()=>{const set=new Set((await cgames()).map(g=>String(g.root)).filter(r=>r.startsWith('n:')).map(r=>r.slice(2)));const d0=N.def&&await N.def();if(d0)set.add(d0);
 if(!set.size)return toast('Nenhuma pasta salva. Use SELECIONAR PASTA DE ROMs.');for(const d of set){try{await scanNative(d)}catch(e){toast('Pasta indisponível: '+((e&&e.message)||e))}}};
window.openUrl=u=>N.open(u);window.openOut=u=>N.open(u);
const _thumb=window.thumb;window.thumb=async f=>f&&f.native?_thumb(new Blob([await f.arrayBuffer()])):_thumb(f);
const _grf=window.getRefFiles;window.getRefFiles=async function(g,ask){if(!String(g.root).startsWith('n:'))return _grf(g,ask);const out=[];
 for(const fi of g.files){let f=SESS[g.root+'|'+fi.path];if(!f){try{f=await N.resolve(g,fi)}catch(e){throw new Error('MISSING:'+fi.path)}}out.push(f)}return out};
const _play=window.play;window.play=async function(g){const m=g.files[g.main||0];
 if(m&&m.blob&&m.blob.native){if(N.kind=='desktop'){const o=URL.createObjectURL;URL.createObjectURL=()=>m.blob.url;try{return _play(g)}finally{URL.createObjectURL=o}}
  toast('Carregando ROM...');const f=m.blob,ch=[];for(let p=0;p<f.size;p+=4194304)ch.push(new Uint8Array(await f.rd(p,Math.min(4194304,f.size-p))));m.blob=new Blob(ch)}
 return _play(g)};
if(E){window.GL_openRoms=async()=>{await E.openRoms();window.__romsOpened=true};window.GL_openBase=()=>E.openBase();window.GL_openDownloads=()=>E.openDownloads();
 // Ao voltar da pasta de ROMs, procura novos jogos sozinho e mostra o total.
 window.addEventListener('focus',async()=>{if(!window.__romsOpened)return;window.__romsOpened=false;try{const d=await N.def();if(d){await scanNative(d,true);toast((await cgames()).length+' jogo(s) na biblioteca')}}catch(e){}})}
// ---- Navegador integrado (Windows): a página abre numa visão nativa separada (sem ponte, sem Node, sessão isolada) ----
if(E&&E.webOpen){
 window.openWeb=function(u0){
  if(typeof onlOk=='function'&&!onlOk())return toast('Recursos online estão desligados');
  let host,inp,msg,cur='';
  const fechar=()=>{if(window.__webOpen){window.__webOpen=false;E.onWeb(null);E.webClose().catch(()=>{})}closeD()};
  panel(c=>{c.style.width='96vw';c.style.maxWidth='none';const r=el('div','row',null,c);r.style.margin='0 0 .5rem';
   inp=document.createElement('input');inp.dataset.f=1;inp.placeholder='Endereço ou pesquisa';inp.style.cssText='flex:1;min-width:220px;font-size:1.1rem;padding:.5em;border-radius:6px;border:2px solid #2b5;background:#0b140d;color:#fff';
   msg=el('p',0,'Dica: a tecla F9 volta ao Game Linkd.',c);msg.style.cssText='margin:.2rem 0;font-size:.9rem;color:#9db39d';
   host=el('div',0,null,c);host.style.cssText='height:60vh;background:#000;border-radius:6px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#cfe;padding:1rem;text-align:center';host.textContent='Digite um endereço ou uma pesquisa.';
   const rect=()=>{const b=host.getBoundingClientRect();return{x:b.x,y:b.y,w:b.width,h:b.height}};
   const erro=(t,url)=>{E.webBounds(null).catch(()=>{});host.innerHTML='';el('p',0,t,host).style.maxWidth='640px';const rr=el('div','row',null,host);rr.style.justifyContent='center';
    bt(rr,'↻ Tentar de novo',()=>ir(url||cur));bt(rr,'↗ Abrir externamente',()=>E.open(url||cur));bt(rr,'Voltar ao Game Linkd',fechar)};
   const ir=async t=>{if(!String(t||'').trim())return;msg.textContent='Carregando...';host.innerHTML='';window.__webOpen=true;
    E.onWeb(m=>{if(m.type=='state'){cur=m.url||cur;if(m.url)inp.value=m.url;msg.textContent=m.loading?'Carregando...':(m.title||'Pronto')+'  ·  F9 volta ao Game Linkd'}
     else if(m.type=='error'){msg.textContent='Falha ao carregar';erro(m.msg,m.url)}
     else if(m.type=='blocked'){toast(m.msg)}else if(m.type=='close-request'){fechar()}});
    try{await E.webOpen(t,rect())}catch(e){erro(String(e.message||e).replace(/^Error invoking remote method '[^']+': (Error: )?/,''),'')}};
   bt(r,'◀',()=>E.webNav('back'));bt(r,'▶',()=>E.webNav('forward'));bt(r,'↻',()=>E.webNav('reload'));bt(r,'⌂',()=>ir(S.home||'https://duckduckgo.com'));r.appendChild(inp);
   bt(r,'Ir',()=>ir(inp.value));bt(r,'↗ Abrir fora',()=>cur&&E.open(cur));bt(r,'✕ Fechar',fechar);
   inp.onclick=e=>{if(e.detail===0)ir(inp.value)};
   const sync=()=>{if(window.__webOpen&&host.isConnected)E.webBounds(rect()).catch(()=>{})};window.addEventListener('resize',sync);new ResizeObserver(sync).observe(host);
   if(u0)setTimeout(()=>ir(u0),50);else inp.focus()});
  // se o painel for fechado ou substituído por qualquer meio, a visão nativa é destruída
  const mo=new MutationObserver(()=>{if(!window.__webOpen){mo.disconnect();return}if(!host||!host.isConnected||$('xd').classList.contains('hide')){mo.disconnect();window.__webOpen=false;E.onWeb(null);E.webClose().catch(()=>{})}});
  mo.observe($('xd'),{attributes:true,attributeFilter:['class'],childList:true,subtree:true})}}
// Procura automática ao abrir: pasta "ROMs" ao lado do programa (Windows).
if(S.wiz)Promise.resolve(N.def&&N.def()).then(d=>{if(d)return scanNative(d,true)}).catch(()=>{});
else Promise.resolve(N.def&&N.def()).catch(()=>{});   // 1ª vez: só cria as pastas; o assistente guia o resto
})();
