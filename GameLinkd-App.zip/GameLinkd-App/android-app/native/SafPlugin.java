package com.gamelinkd.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;

import androidx.activity.result.ActivityResult;
import androidx.documentfile.provider.DocumentFile;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.InputStream;

/** Acesso a pastas pelo seletor oficial do Android (Storage Access Framework). Somente leitura. */
@CapacitorPlugin(name = "Saf")
public class SafPlugin extends Plugin {

    @PluginMethod
    public void pickTree(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, i, "treePicked");
    }

    @ActivityCallback
    private void treePicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("Seleção cancelada");
            return;
        }
        Uri u = result.getData().getData();
        try {
            getContext().getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        JSObject o = new JSObject();
        o.put("uri", u.toString());
        call.resolve(o);
    }

    @PluginMethod
    public void list(PluginCall call) {
        String tree = call.getString("tree");
        if (tree == null) { call.reject("Pasta não informada"); return; }
        DocumentFile root = DocumentFile.fromTreeUri(getContext(), Uri.parse(tree));
        if (root == null || !root.canRead()) {
            call.reject("Sem permissão para ler a pasta. Selecione-a novamente.");
            return;
        }
        JSArray arr = new JSArray();
        int[] count = {0};
        walk(root, "", arr, count, 0);
        JSObject o = new JSObject();
        o.put("files", arr);
        call.resolve(o);
    }

    private void walk(DocumentFile dir, String prefix, JSArray arr, int[] count, int depth) {
        if (depth > 12 || count[0] > 200000) return;
        for (DocumentFile f : dir.listFiles()) {
            String name = f.getName();
            if (name == null) continue;
            if (f.isDirectory()) {
                walk(f, prefix + name + "/", arr, count, depth + 1);
            } else if (f.isFile()) {
                JSObject o = new JSObject();
                o.put("rel", prefix + name);
                o.put("name", name);
                o.put("size", f.length());
                o.put("uri", f.getUri().toString());
                arr.put(o);
                count[0]++;
            }
        }
    }

    @PluginMethod
    public void read(PluginCall call) {
        String uri = call.getString("uri");
        long offset = call.getData().optLong("offset", 0);
        int length = call.getInt("length", 65536);
        if (uri == null) { call.reject("Arquivo não informado"); return; }
        try (InputStream in = getContext().getContentResolver().openInputStream(Uri.parse(uri))) {
            if (in == null) { call.reject("Arquivo indisponível"); return; }
            long skipped = 0;
            while (skipped < offset) {
                long s = in.skip(offset - skipped);
                if (s <= 0) break;
                skipped += s;
            }
            byte[] buf = new byte[length];
            int total = 0;
            while (total < length) {
                int r = in.read(buf, total, length - total);
                if (r < 0) break;
                total += r;
            }
            JSObject o = new JSObject();
            o.put("data", Base64.encodeToString(buf, 0, total, Base64.NO_WRAP));
            o.put("bytes", total);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("Falha de leitura: " + e.getMessage());
        }
    }
}
